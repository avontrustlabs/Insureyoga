<div class="chart">
    <canvas id="{{ $id }}" style="height: 249px; width: 548px;" width="1096" height="498"></canvas>
</div>