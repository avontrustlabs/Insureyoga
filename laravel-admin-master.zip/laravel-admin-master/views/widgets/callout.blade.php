<div class="callout callout-{{ $style }}">
    @if(isset($title))
    <h4>{{ $title }}</h4>
    @endif
    {!! $content !!}
</div>