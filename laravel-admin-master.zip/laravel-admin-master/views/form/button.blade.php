<div class="form-group">

    <label class="col-sm-2 control-label"></label>

    <div class="col-sm-6">
        <input type='button' id='{{$id}}' value='{{$label}}' class="btn {{ $class }}" {!! $attributes !!} />
    </div>
</div>