<div class="callout callout-warning">
    <h3>Oops! Something went wrong.</h3>
    <p>&nbsp;</p>
    <p><h4>In <strong style="font-style:italic">`{{ basename($e->getFile()) }}`</strong> line <strong style="font-style:italic">`{{$e->getLine()}}`</strong> : <strong style="font-style:italic">{{$e->getMessage()}}</strong></h4></p>
</div>