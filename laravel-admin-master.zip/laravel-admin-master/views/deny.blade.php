<div class="callout callout-warning">
    <h3>Oops! Something went wrong.</h3>
    <p>&nbsp;</p>
    <p><h4><strong style="font-style:italic">{{ trans('admin::lang.deny') }}!</strong></h4></p>
</div>