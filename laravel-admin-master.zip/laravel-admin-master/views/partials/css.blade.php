@foreach($css as $c)
    <link rel="stylesheet" href="{{ asset("$c") }}">
@endforeach