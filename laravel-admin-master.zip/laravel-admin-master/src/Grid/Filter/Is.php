<?php

namespace Encore\Admin\Grid\Filter;

class Is extends AbstractFilter
{
}
