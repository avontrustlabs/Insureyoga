<?php

namespace Encore\Admin\Grid\Filter\Field;

class Text
{
    public function variables()
    {
        return [];
    }

    public function name()
    {
        return 'text';
    }
}
