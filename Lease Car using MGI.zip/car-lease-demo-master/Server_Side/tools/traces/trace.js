var create = require(__dirname+'/CRUD/create.js');
exports.create = create.create;

var read = require(__dirname+'/CRUD/read.js');
exports.read = read.read;

var update = require(__dirname+'/CRUD/update.js');
exports.update = update.update;