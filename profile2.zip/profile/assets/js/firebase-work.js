
// Initialize Firebase
var config = {
apiKey: "AIzaSyBtuc7YoMakaFLEnlqE-QUHHIlzCmxOQjE",
authDomain: "insureyoga-3312b.firebaseapp.com",
databaseURL: "https://insureyoga-3312b.firebaseio.com",
storageBucket: "insureyoga-3312b.appspot.com",
messagingSenderId: "930269907800"
};
firebase.initializeApp(config);

// Form data
var fName = document.getElementsByClassName("f-name")[0],
	lName = document.getElementsByClassName("l-name")[0],
	email = document.getElementsByClassName("email")[0],
	holidayCheck = document.getElementsByClassName('holiday-check')[0];
	mixedCheck = document.getElementsByClassName("mixed-check")[0],
	workCheck = document.getElementsByClassName("work-check")[0],
	assetType = document.getElementsByClassName("type-select")[0],
	colorSelect = document.getElementsByClassName("color-select")[0],
	thirdParty = document.getElementsByClassName("third-party")[0],
	linkedLedgers = document.getElementsByClassName("linked-ledgers")[0],
	finishBtn = document.getElementsByClassName("btn-finish")[0];

	// console.log(colorSelect[colorSelect.selectedIndex].value);



// Firebase config
var ref = firebase.database().ref("userdata");
finishBtn.addEventListener("click",function(){
	ref.push({
		firstName : fName.value,
		lastName : lName.value,
		email : email.value,
		holiday : holidayCheck.checked,
		mixed: mixedCheck.checked,
		workCheck : workCheck.checked,
		type : assetType[assetType.selectedIndex].value,
		color : colorSelect[colorSelect.selectedIndex].value,
		thirdParty : thirdParty.value,
		linkedLedgers : linkedLedgers.value
	});
})




	// alert("done!!");

